<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
header('Content-type: application/json');
include'dom/simple_html_dom.php';
$html = file_get_html("https://www.unipin.com/id/garena/free-fire");

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

$parsed = get_string_between($html, 'rgid', 'playerid');

$rgid = explode("'",$parsed);
$token = $rgid[2];

$ch = curl_init();
$vars = json_encode(array(
    'productId' => '3',
    'itemId' => '10',
    'catalogId' => '65',
    'paymentId' => '749',
    'gameId' => $_GET['id'],
    'product_ref' => 'REG',
    'product_ref_denom' => 'AE'
    ));
curl_setopt($ch, CURLOPT_URL,"https://www.unipin.com/id/garena/inquiry");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,"rgid=RURnL3R2RzNhYkZ3VzdDTkNCTVZwQT09&playerid=".$_GET['id']."&game=free-fire&did=513&pid=56&influencer=");  //POST Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers[] = 'Host: www.unipin.com';
$headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
$headers[] = 'Accept-Language: id';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'X-CSRF-TOKEN: Aiv9nWBJUsNggG3zCk7zBpgG1IIB5mg0Rscl0bu4';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Referer: https://www.unipin.com/id/garena/free-fire';
$headers[] = 'Connection: keep-alive';
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$res = curl_exec($ch);
echo $res;
$message = json_decode($res,true);

$datas = $message['message'];
$htmlx = file_get_html("https://www.unipin.com/id/garena/checkout/".$datas);

$nick = $htmlx->find(".payment-modal-listvalue", 1)->innertext;
$nickname = str_replace(" ","",$nick);
echo "Nickname Mu Adalah : ".$nickname;
// foreach($htmlx->find('.payment-modal-listvalue') as $lah){
// 
// $p = explode('<div class="payment-modal-listvalue">',$lah);
// 
// $mmq = explode("</div>",$p[1]);
// echo $mmq[0];
// }

?>
