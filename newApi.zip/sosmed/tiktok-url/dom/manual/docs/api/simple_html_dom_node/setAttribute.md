# setAttribute

```php
setAttribute ( string $name, string $value )
```

| Parameter | Description
| --------- | -----------
| `name`    | Attribute name
| `value`   | Attribute value

Adds or sets an attribute in the current node to the specified value.