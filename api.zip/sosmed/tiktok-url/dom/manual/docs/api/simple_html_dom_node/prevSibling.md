# prevSibling

```php
prevSibling ( ) : object
```

This is a wrapper for [`previous_sibling`](../previous_sibling/).