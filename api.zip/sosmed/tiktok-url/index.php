<?php
include'dom/simple_html_dom.php';
echo '<pre>';
// header('Content-type: appliaction/json');
if(isset($_GET['url']))
{

if(!preg_match("/vt.tiktok.com/i", $_GET['url']))
{
$data = array(
              'Result' => array(
                       'Author' => 'Nguyen Thu Wan',
                       'Status' => '404'
                     ),
              'Error_msg' => 'Invalid Url'
       );
       print_r(json_encode($data, JSON_PRETTY_PRINT));
}else{
$html = file_get_html($_GET['url']);



foreach($html->find('title') as $element)
       $montu = explode("(@",$element->innertext);
       $nama = $montu[0];
       $tapasya = explode(")",$montu[1]);
       if($tapasya[0] == "")
       
       $data = array(
              'Result' => array(
                       'Author' => 'Nguyen Thu Wan',
                       'Status' => '404'
                     ),
              'Error_msg' => 'Invalid Url'
       );
       else
       $data = array(
              'Result' => array(
                       'Author' => 'Nguyen Thu Wan',
                       'Status' => '200'
                     ),
              'Nama' => $nama,
              'Username' => $tapasya[0]
       );
       
       print_r(json_encode($data, JSON_PRETTY_PRINT));

}}else{

       $data = array(
              'Result' => array(
                       'Author' => 'Nguyen Thu Wan',
                       'Status' => '404'
                     ),
              'Error_msg' => 'Please insert url'
       );
       print_r(json_encode($data, JSON_PRETTY_PRINT));
}
?>