<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
header('Content-type: application/json');
if($_GET['token'] == 'NguyenThuWan')
{
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,"https://www.topbos.com/web/infullRequest.do");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,'userId='.$_GET['id'].'&costKey=com.neptune.domino.coincard0035&infullType=10&version='); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers[] = 'Host: www.topbos.com';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0';
$headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Referer: https://www.topbos.com/web/webInfull.do';
$headers[] = 'Connection: keep-alive';

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$res = curl_exec($ch);
$data = json_decode($res,true);
$nick =  $data['message']['nickName'];
$id = $_GET['id'];
if($nick != null)
{
$print = array(
  			'result' => array(
  				'status' => '200',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'nickname' => $nick,
  			'userid' => $id
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
}else{
    $print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Invalid Id'
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
}
  print_r($hasil);
}else{
$print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Missing Token or Parameter'
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
  print_r($hasil);    
}
?>
